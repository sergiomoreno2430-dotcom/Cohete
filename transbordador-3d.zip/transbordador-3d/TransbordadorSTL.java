import java.io.*;
import java.nio.*;
import java.util.*;

/**
 * Genera un STL binario del transbordador espacial (orbitador + tanque externo + 2 SRB).
 * Uso: java TransbordadorSTL [salida.stl] [segmentos] [escala] [plataforma:true|false]
 *   segmentos: caras alrededor de cada cuerpo (por defecto 64)
 *   escala:    mm por unidad del modelo (1.0 -> ~112 mm de alto)
 * Eje Z hacia arriba; el modelo se apoya sobre la plataforma (z = -2 .. 0.2).
 */
public class TransbordadorSTL {

    static final double OY = -13, SX = 11.6;

    static final double[][] ET  = {{0,17},{4.5,17.5},{7.4,18.7},{8.4,21},{8.4,61},{8.65,61},{8.65,63},{8.4,63},{8.4,81},{8.65,81},{8.65,83},{8.4,83},{8.4,95},{8.1,98},{7.4,101},{6.3,104},{4.9,106.5},{3.2,109},{1.4,111},{0,112}};
    static final double[][] SRB = {{0,0},{2.2,0},{1.5,4},{3.0,7},{3.7,10},{3.7,42},{3.85,42},{3.85,43.5},{3.7,43.5},{3.7,60},{3.85,60},{3.85,61.5},{3.7,61.5},{3.7,76},{3.4,79},{2.8,82},{2.0,85},{1.1,88},{0,91}};
    static final double[][] ORB = {{0,16},{4.0,16},{4.8,20},{5.0,26},{5.0,62},{4.6,70},{3.8,78},{2.6,85},{1.2,89},{0,90.5}};
    static final double[][] SSME = {{0,13},{0.4,13},{0.7,11.5},{1.2,10},{1.6,10},{1.3,11.5},{1.0,13},{0.8,15},{0.8,17.5},{0,17.5}};
    static final double[][] OMS = {{0,18},{1.4,18},{1.6,24},{1.4,32},{0,36}};
    static final double[][] BASE = {{0,-2},{21,-2},{21,-1},{20,0.2},{0,0.2}};
    static final double[][] WING = {{4.5,17},{24,17},{24,21},{13,41},{4.5,52}};
    static final double[][] TAIL = {{4.5,19},{4.5,38},{18.5,27},{18.5,20}};

    interface Map3 { double[] f(double u, double v, double w); }

    static final List<double[][]> tris = new ArrayList<>();

    static void add(double[] a, double[] b, double[] c) { tris.add(new double[][]{a, b, c}); }

    /** Sólido de revolución alrededor de un eje vertical en (cx, cy). Normales hacia afuera. */
    static void rev(double[][] pf, double cx, double cy, int seg) {
        for (int k = 0; k < pf.length - 1; k++) {
            double r0 = pf[k][0], z0 = pf[k][1], r1 = pf[k+1][0], z1 = pf[k+1][1];
            for (int i = 0; i < seg; i++) {
                double t0 = 2*Math.PI*i/seg, t1 = 2*Math.PI*(i+1)/seg;
                double[] p0 = {cx + r0*Math.cos(t0), cy + r0*Math.sin(t0), z0};
                double[] p1 = {cx + r0*Math.cos(t1), cy + r0*Math.sin(t1), z0};
                double[] q0 = {cx + r1*Math.cos(t0), cy + r1*Math.sin(t0), z1};
                double[] q1 = {cx + r1*Math.cos(t1), cy + r1*Math.sin(t1), z1};
                if (r0 > 1e-9 || r1 > 1e-9) {
                    if (r0 > 1e-9) add(p0, p1, q1);   // triángulo degenerado omitido
                    if (r1 > 1e-9) add(p0, q1, q0);
                }
            }
        }
    }

    /** Prisma de espesor 2t a partir de un polígono convexo; corrige la orientación de normales. */
    static void prism(double[][] poly, double t, Map3 m) {
        int n = poly.length;
        double[][] lo = new double[n][], hi = new double[n][];
        double[] c = new double[3];
        for (int i = 0; i < n; i++) {
            lo[i] = m.f(poly[i][0], poly[i][1], -t);
            hi[i] = m.f(poly[i][0], poly[i][1],  t);
            for (int k = 0; k < 3; k++) c[k] += (lo[i][k] + hi[i][k]) / (2.0*n);
        }
        List<double[][]> loc = new ArrayList<>();
        for (int i = 1; i < n-1; i++) {
            loc.add(new double[][]{lo[0], lo[i], lo[i+1]});
            loc.add(new double[][]{hi[0], hi[i], hi[i+1]});
        }
        for (int i = 0; i < n; i++) {
            int j = (i+1) % n;
            loc.add(new double[][]{lo[i], hi[i], hi[j]});
            loc.add(new double[][]{lo[i], hi[j], lo[j]});
        }
        for (double[][] T : loc) {
            double[] nrm = normal(T[0], T[1], T[2]);
            double[] g = {(T[0][0]+T[1][0]+T[2][0])/3 - c[0], (T[0][1]+T[1][1]+T[2][1])/3 - c[1], (T[0][2]+T[1][2]+T[2][2])/3 - c[2]};
            if (nrm[0]*g[0] + nrm[1]*g[1] + nrm[2]*g[2] < 0) add(T[0], T[2], T[1]); else add(T[0], T[1], T[2]);
        }
    }

    static double[] normal(double[] a, double[] b, double[] c) {
        double ux = b[0]-a[0], uy = b[1]-a[1], uz = b[2]-a[2];
        double vx = c[0]-a[0], vy = c[1]-a[1], vz = c[2]-a[2];
        double nx = uy*vz - uz*vy, ny = uz*vx - ux*vz, nz = ux*vy - uy*vx;
        double l = Math.sqrt(nx*nx + ny*ny + nz*nz);
        return l < 1e-12 ? new double[]{0,0,0} : new double[]{nx/l, ny/l, nz/l};
    }

    static void build(int seg, boolean plataforma) {
        int segN = Math.max(12, seg * 18 / 32);
        rev(ET, 0, 0, seg);
        rev(SRB,  SX, 0, seg);
        rev(SRB, -SX, 0, seg);
        rev(ORB, 0, OY, seg);
        double[][] ssme = {{0, OY-2}, {1.9, OY+1}, {-1.9, OY+1}};
        for (double[] p : ssme) rev(SSME, p[0], p[1], segN);
        rev(OMS,  2.7, OY-3.9, Math.max(12, seg/2));
        rev(OMS, -2.7, OY-3.9, Math.max(12, seg/2));
        prism(WING, 0.6, (u,v,w) -> new double[]{ u, OY+1.5+w, v});
        prism(WING, 0.6, (u,v,w) -> new double[]{-u, OY+1.5+w, v});
        prism(TAIL, 0.5, (u,v,w) -> new double[]{ w, OY-u, v});
        double[][] zr = {{28,34},{68,74}};
        for (double[] r : zr) {
            double[][] rect = {{7.5,r[0]},{11.6,r[0]},{11.6,r[1]},{7.5,r[1]}};
            prism(rect, 1.2, (u,v,w) -> new double[]{ u, w, v});
            prism(rect, 1.2, (u,v,w) -> new double[]{-u, w, v});
        }
        double[][] zo = {{34,40},{64,70}};
        for (double[] r : zo)
            prism(new double[][]{{-2.5,r[0]},{2.5,r[0]},{2.5,r[1]},{-2.5,r[1]}}, 1.5, (u,v,w) -> new double[]{u, -9+w, v});
        if (plataforma) rev(BASE, 0, 0, seg);
    }

    static void writeBinary(String path, double scale) throws IOException {
        ByteBuffer bb = ByteBuffer.allocate(84 + 50 * tris.size()).order(ByteOrder.LITTLE_ENDIAN);
        byte[] head = new byte[80];
        byte[] txt = "Transbordador espacial - modelo para impresion 3D (mm)".getBytes("US-ASCII");
        System.arraycopy(txt, 0, head, 0, Math.min(80, txt.length));
        bb.put(head);
        bb.putInt(tris.size());
        for (double[][] T : tris) {
            double[] n = normal(T[0], T[1], T[2]);
            for (double x : n) bb.putFloat((float) x);
            for (double[] v : T) for (double x : v) bb.putFloat((float) (x * scale));
            bb.putShort((short) 0);
        }
        try (FileOutputStream fo = new FileOutputStream(path)) { fo.write(bb.array()); }
    }

    public static void main(String[] args) throws IOException {
        String out = args.length > 0 ? args[0] : "transbordador.stl";
        int seg = args.length > 1 ? Integer.parseInt(args[1]) : 64;
        double scale = args.length > 2 ? Double.parseDouble(args[2]) : 1.0;
        boolean plat = args.length > 3 ? Boolean.parseBoolean(args[3]) : true;
        build(seg, plat);
        writeBinary(out, scale);

        double[] mn = {1e9,1e9,1e9}, mx = {-1e9,-1e9,-1e9};
        double vol = 0;
        for (double[][] T : tris) {
            for (double[] v : T) for (int k = 0; k < 3; k++) { mn[k] = Math.min(mn[k], v[k]); mx[k] = Math.max(mx[k], v[k]); }
            double[] a = T[0], b = T[1], c = T[2];
            vol += (a[0]*(b[1]*c[2]-b[2]*c[1]) - a[1]*(b[0]*c[2]-b[2]*c[0]) + a[2]*(b[0]*c[1]-b[1]*c[0])) / 6.0;
        }
        System.out.printf("Escrito %s: %d triangulos%n", out, tris.size());
        System.out.printf("Tamano (mm): X=%.1f  Y=%.1f  Z=%.1f%n", (mx[0]-mn[0])*scale, (mx[1]-mn[1])*scale, (mx[2]-mn[2])*scale);
        System.out.printf("Volumen aprox (suma de piezas, con solapes): %.0f mm3%n", vol*scale*scale*scale);
    }
}
