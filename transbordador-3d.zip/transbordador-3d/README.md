# Transbordador espacial para impresión 3D

Modelo paramétrico de un transbordador espacial (orbitador, tanque externo naranja y dos cohetes propulsores) que genera un STL binario listo para el slicer.

## Archivos

- `TransbordadorSTL.java`: generador del modelo (Java, sin dependencias).
- `transbordador.stl`: STL generado con los valores por defecto (64 segmentos, escala 1.0, con plataforma; ~48 × 52,5 × 114 mm).

## Uso

```
javac TransbordadorSTL.java
java TransbordadorSTL [salida.stl] [segmentos] [escala] [plataforma]
```

| Argumento | Por defecto | Descripción |
|-----------|-------------|-------------|
| salida.stl | transbordador.stl | Archivo de salida |
| segmentos | 64 | Caras alrededor de cada cuerpo (más = más suave) |
| escala | 1.0 | mm por unidad del modelo |
| plataforma | true | Incluye la base de apoyo |

Ejemplo (unos 17 cm de alto): `java TransbordadorSTL salida.stl 96 1.5 true`

## Consejos de impresión

- El modelo está hecho de sólidos solapados, no de una malla unida. Si el slicer marca errores, usa la reparación de malla.
- Las alas y la deriva son finas (1,2 mm a escala 1). Con escalas menores de 1,5 conviene engrosarlas o usar boquilla de 0,2 mm.
- Activa soportes para alas y uniones, o imprime el cohete de pie sobre la plataforma.
- El STL no guarda colores: para naranja y blanco, separa por piezas o pinta después.
